﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DateConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                log4net.Config.BasicConfigurator.Configure();
                DateTime startDate = new DateTime();
                DateTime endDate = new DateTime();

                if (DateTime.TryParse(args[0], System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out  startDate) && DateTime.TryParse(args[1], System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out  endDate))
                {
                    Console.WriteLine(((startDate.ToString("dd"))) + "-" + endDate.ToString("dd.MM.yyyy"));
                    Console.WriteLine(startDate.ToString("dd.MM") + "-" + endDate.ToString("dd.MM.yyyy"));
                    Console.WriteLine(startDate.ToString("dd.MM.yyyy") + "-" + endDate.ToString("dd.MM.yyyy"));
                }
                else
                {
                    Console.WriteLine("Date is not Valid");
                }
            }
            catch (Exception ex)
            {
                ILog logger = LogManager.GetLogger(typeof(Program));
                logger.Error("Error Message: " + ex.Message, ex);
            }
        }
    }
}
